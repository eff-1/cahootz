---
title: "Decision Log and Change Log"
project: CAHOOTZ
version: "v0.1 (Draft for founder review)"
date: "5 November 2026"
status: PROPOSED baseline (awaiting founder approval)
---

# Decision Log and Change Log

> Version v0.1 (Draft for founder review) · 5 November 2026 · Index: [MASTER_BLUEPRINT.md](MASTER_BLUEPRINT.md) · Tracker: [PROJECT_TRACKER.md](PROJECT_TRACKER.md) · Decisions: [DECISION_LOG.md](DECISION_LOG.md)
> Labels: **[CONFIRMED]** fixed by the founder · **[PROPOSED]** recommendation awaiting approval · **[OPEN]** unresolved.


## Decision log

| Decision ID | Decision | Rationale | Alternatives considered | Approval status | Date | Impacted modules |
|---|---|---|---|---|---|---|
| D-001 | Product is web-first with future mobile apps | Brief | Native-first | CONFIRMED | 2026-11-05 | All |
| D-002 | Study Together is the signature feature | Brief | — | CONFIRMED | 2026-11-05 | Study sessions |
| D-003 | Keep XP and spendable coins separate; coins non-withdrawable | Brief | Single currency | CONFIRMED | 2026-11-05 | Wallet |
| D-004 | No random video matching; no recording by default | Brief | — | CONFIRMED | 2026-11-05 | Video, Moderation |
| D-005 | Modular monolith first | Founder preference in brief | Microservices | CONFIRMED | 2026-11-05 | Architecture |
| D-006 | Use append-only ledger for coins and XP | Brief | Editable balance | CONFIRMED | 2026-11-05 | Wallet |
| D-007 | MVP excludes AI, video, coins, groups | Focus on core loop; cost and safety | Include AI early | PROPOSED | 2026-11-05 | Roadmap |
| D-008 | Server-authoritative session timer and single-writer state machine | Correctness under concurrency | Client-driven timer | PROPOSED | 2026-11-05 | Study sessions |
| D-009 | Generic org-unit tree for academic structure | Institutional variation | Fixed faculty/department tables | PROPOSED | 2026-11-05 | Academic data |
| D-010 | Start with pgvector instead of a separate vector DB | Operational simplicity | Dedicated vector DB | PROPOSED | 2026-11-05 | AI |
| D-011 | North Star: Weekly Completed Study Sessions per Active Student | Captures core loop | DAU | PROPOSED | 2026-11-05 | Metrics |


_Add new decisions as new rows. Never edit history; supersede with a new decision._
